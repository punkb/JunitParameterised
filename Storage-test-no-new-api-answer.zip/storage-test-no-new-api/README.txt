Using JUnit 4.10 or later:
1) Build on the supplied test class to write a complete set of JUnit test assertions for the StorageAPI class based on the javadoc.

Test Details:
Negative/error test cases must be included.
The higher the test coverage, the better.
The less duplication in your tests, the better
You should not change StorageImplementation.java or StorageAPI.java.
Please email back a tarball like the one you received containing the completed tests





				**********************************Test Instruction*********************************
				
				Please use the TestSuite file for running all test cases.
				I wanted to use ant build to run the Junit suite but because of the time constraint could not. 
